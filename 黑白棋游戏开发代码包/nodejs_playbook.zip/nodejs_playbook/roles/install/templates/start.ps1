﻿#参数申明
#param($a,$b,$c)
param($a)
#$webapps_path = $a  #
#$SiteName = $b
#$node_path = "$webapps_path\$SiteName" #node_path

#执行node
#node $node_path

#执行forever
$forever_path = $a
#$forever_path = "$forever_path\$SiteName"
forever stop $forever_path
forever start $forever_path
#exit