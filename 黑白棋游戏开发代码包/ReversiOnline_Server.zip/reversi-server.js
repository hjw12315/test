'use strict'

let express = require('express')();
let http = require('http').Server(express);
let io = require('socket.io')(http);
let port = 12002;

http.listen(port, function() {
	console.log('server start');
    console.log('listening on:' + port);
});

let MaxCount = 20;//允许同时连接的对战房间数量
let hall = null;//接入大厅
let queue = null;//匹配队列
let rooms = [];//对战房间

hall = new Hall();

queue = new Queue();

function Hall() {
    this.people = 0;
    this.socket = null;
}

function Room(){
	this.people = 0;
    this.socket = null;
}

function Queue(){
    this.people = 0;
    this.socket = null;
}

for(let n = 0;n < MaxCount;n++){
	rooms[n] = new Room();
}

function getFreeRoom(){
	for(let n = 0;n < MaxCount;n++){
		if(rooms[n].people === 0){
			return n;
		}
	}
	return -1;
}

io.people = 0;
io.on('connection',function(socket){
    io.people++;
    console.log('someone connected');
    socket.on('disconnect',function(){
        io.people--;
        console.log('someone disconnected');
    });
})

hall.socket = io.of('/hall').on('connection', function(socket) {

	hall.people++;

    console.log('a player connected.There are '+hall.people+' people in hall');

	hall.socket.emit('people changed',hall.people);

    socket.on('disconnect',function(){
        hall.people--;
		console.log('a player disconnected.There are '+hall.people+' people in hall');
		hall.socket.emit('people changed',hall.people);
    });
});

queue.socket = io.of('/queue').on('connection',function(socket){

	queue.people++;

    console.log('someone connect queue socket.There are '+queue.people+' people in queue');

    if(queue.people === 1){
		socket.emit('set stand','black');
	}else if(queue.people === 2){
		socket.emit('set stand','white');
		let roomId = getFreeRoom();
        console.log(roomId+"roomId");
		if(roomId >= 0){
			queue.socket.emit('match success',roomId);
            console.log('match success.There are '+queue.people+' people in queue');
		}else{
            console.log('no free room!');
        }
	}

	socket.on('cancel match',function(){
		queue.people--;
        console.log('someone cancel match.There are '+queue.people+' people in queue');
	});

    socket.on('disconnect',function(){
        queue.people--;
        console.log('someone disconnected match.There are '+queue.people+' people in queue');
    });

});

for(let i = 0;i < MaxCount;i++){
	rooms[i].socket = io.of('/rooms'+i).on('connection',function(socket){

		rooms[i].people++;
		console.log('some one connected room'+i+'.There are '+rooms[i].people+' people in the room');

		socket.on('update chessboard',function(chessCoor){
			socket.broadcast.emit('update chessboard',chessCoor);
		});

		socket.on('force change turn',function(){
			socket.broadcast.emit('force change turn');
		});

		socket.on('disconnect',function(){
			rooms[i].people--;
            console.log('someone disconnected room' + i + '.There are ' + rooms[i].people + ' people in the room');
            socket.broadcast.emit('player leave');
		});

	});
}
