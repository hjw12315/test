export enum STATE{
    NONE = 0,
    START = 1,
    OVER = 2
}
export enum PIECE_STATE {
    IDLE = 0,
    PRESS = 1
}