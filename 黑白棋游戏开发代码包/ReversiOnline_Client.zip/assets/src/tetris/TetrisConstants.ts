export enum STATE{
    NONE = 0,
    START = 1,
    OVER = 2
}