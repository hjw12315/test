// export const DIR = cc.Enum({
//     LEFT:-1,
//     UP:-1,
//     RIGHT:-1,
//     DOWN:-1
// });
export enum DIR{
    LEFT = 1,
    UP = 2,
    RIGHT = 3,
    DOWN = 4
}
export enum STATE{
    NONE = 0,
    START = 1,
    OVER = 2
}