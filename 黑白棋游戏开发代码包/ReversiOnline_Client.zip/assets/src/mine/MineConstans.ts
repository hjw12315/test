export enum STATE{
    NONE = 0,
    START = 1,
    OVER = 2
}

export enum PIECE_TYPE {
    OPEN0 = 0,
    OPEN1 = 1,
    OPEN2 = 2,
    OPEN3 = 3,
    OPEN4 = 4,
    OPEN5 = 5,
    OPEN6 = 6,
    OPEN7 = 7,
    OPEN8 = 8,
    BOMB = 9
}

export enum PIECE_STATE {
    PENDING = 1,
    FLAG = 2,
    OPEN = 3
}
