export enum STATE{
    NONE = 0,
    READY = 1,
    START = 2,
    OVER = 3
}