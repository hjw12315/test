export class GobangPiece {
    constructor(public x:number,public y:number,public color:number){}
}