export const NONE = 0;
export const BLACK = 1;
export const WHITE = 2;