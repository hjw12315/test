export enum DIR{
    LEFT = 1,
    UP = 2,
    RIGHT = 3,
    DOWN = 4
}
export enum STATE{
    NONE = 0,
    START = 1,
    OVER = 2
}